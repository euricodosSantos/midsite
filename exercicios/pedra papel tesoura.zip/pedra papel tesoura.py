from random import choice
print('\033 Vamos jogar JON KEN GO [ PEDRA , PAPEL E TESOURA ] \033')
lista=['Pedra','Tesoura','Papel']
computador=choice(lista)

def pedra(n=0):
    if n==0 and computador=='Pedra':
        print('Houve um empate!  ')
        print(f'vc escolheu {computador} e eu escolhi { computador }')
    if n==0 and computador=='Tesoura':
        print('parabens Voce venceu !! ')
        print(f'Voce escolheu {lista[n]} e eu escolhi {computador} ')
        return 1
    if n == 0  and computador =='Papel':
        print('VOCE PERDEU !! PARA MIM')
        print(f'Voce escolheu {lista[n]} e eu escolhi {computador}')
def papel(n):
    if n ==2 and computador == 'Papel':
        print('Foi um Empate')
        print(f'Voce escolheu {computador} e eu escolhi {computador} ! ')

    if n==2 and computador == 'Pedra':
        print('Parabens voce Venceu !')
        print(f'Voce escolheu {lista[n]}  e eu escolhi {computador}')
        return 1

    if n == 2 and computador=='Tesoura':
        print(f'VOCE PERDEU!')
        print(f'voce Escolheu {lista[n] } e eu escolhi {computador}')

def tesoura(n):
    if n==1 and computador=='Tesoura':
        print(f'Houve um Empate!')
        print(f'voce Escolheu {lista[n]} e eu escolhi {computador}')
    elif n== 1 and computador =='Pedra':
        print(f'VOCE PERDEU!')
        print(f'voce Escolheu {lista[n]} e eu escolhi {computador}')
    elif n ==1 and computador == 'Papel':
        print(f'VOCE Venceu!')
        print(f'voce Escolheu {lista[n]} e eu escolhi {computador}')


while True:


    print(f'{"="}'*80)

    n = int(input(('digite [0] para pedra\n digite [1] para tesoura \n digite[2] para papel \n ||||||||||||||||||| Faça a sua escolha : ')))
    print(F'{"="}'*80)
    pedra(n)
    papel(n)
    tesoura(n)
    print(f'{"="}' * 80)
    op=str(input(('You want play again [ N/Y ] : '))).upper()
    if op!='N' and op!='Y':
        while True:
            print('!!Opcao invalida [ERROR] tente novamente !')
            op = str(input(('You want play again [ N/Y ] : '))).upper()
            if op =='Y' :
                break
            if op == 'N':

                break
    if op == 'N':
        print(f"{'='}" * 80)
        print('Fim      do       JOGO         ')
        break
    else:
        print('')
        continue


