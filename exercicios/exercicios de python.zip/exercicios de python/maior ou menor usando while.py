print('soma de valores e verificador de menor e maior')
a=1
maior=1
menor=1
soma=0
i=0
while True:


        numero=int(input(f'digite o {a} valor :  '))
        if numero > 1000:
                print('So valores compreendidos de [0 a 100] try again')
                continue
        op=str(input(('deseja digitar mais valores [S/N]:  '))).upper()

        a = a + 1

        if a >= 1 and numero > maior :

                maior = numero

        if a >= 1 and numero < menor:
                menor=numero


        if op =='N':

                break

print(f'O maior valor digitado e {maior}')
print(f'O menor valor digitado e {menor }')


