def contar (n):
    for a in range(1,n+1):
        print(a,end=' ')
n=int(input('digite qualquer valor :  '))
contar(n)

