print(' ANAlizando temperatura media')
lista=[]
media=[]
tempanual=0
soma=0
for i in range(1,9):
    lista.append(str(input('digite o mes :  ')))
    lista.append(float(input(f'informe a temperatura de {lista[0]}  : ')))
    media.append(lista[:])
    lista.clear()
for i, c in enumerate(media):
    soma=soma+media[i][1]
    tempanual=soma/(i+1)

print(tempanual)
print('Os meses com temperaturas acima da media sao : ',end=
      '  ')
for i,a in enumerate(media):
    if media[i][1] > tempanual:
        print(f' {media[i][0]} ', end='  ')

