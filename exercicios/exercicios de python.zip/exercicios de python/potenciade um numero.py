print('potencia de um numero')
base=int(input('digite um base do numero que preetende verificar : '))
exp=int(input('digite o seu expoente : '))
resultado=1
for a in range(1,exp+1):
    resultado*=base
print(f'a potencia do numero {base} e de {resultado}!')