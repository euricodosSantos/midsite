print('par ou impar ')
par=0
impar=0
for a in range ( 1,11):
    numero=int(input(f'digite o {a} valor : '))
    if numero % 2==0:
        par=par+1
    else :
        impar=impar+1
print(f'Voce digitou {par} numeros pares ')
print(f'voce tambem digitou {impar} numeros impares')

