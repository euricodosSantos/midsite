print('Imprimindo numeros impares ')
for a in range (1,51):
    if a %2==1:
        print(a)