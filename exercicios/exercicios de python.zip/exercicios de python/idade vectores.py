lista=list()
vectores=list()
for i in range (1, 3):
    vectores.append(int(input('digite a sua idade :  ')))
    vectores.append((float(input('informe a sua altura :  '))))
    lista.append(vectores[:])
    vectores.clear()
lista.reverse()
print('='*40)
for a,i in enumerate(lista):
    print(f' Dados {a+1} : idade {lista[a][0]} , altura : {lista[a][1]} ')



