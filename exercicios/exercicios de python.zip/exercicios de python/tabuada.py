print('TABUADA')
num1=int(input('digite o seu primeiro numero :  '.upper()))
print(f'A tabuada de {num1} :')
for a in range (1,11):
    mult= num1 * a
    print(f'{num1} x {a:2} = {mult:2} ')