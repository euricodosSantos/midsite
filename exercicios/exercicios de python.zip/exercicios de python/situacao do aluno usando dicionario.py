turma={}
for i in range (0,1):
    turma["nome"]=str(input('Nome : '))
    turma["Media"]=float(input(f'Media de {turma["nome"]} : '))
    if turma["Media"]<=9:
        turma["situacao"]='Reprovada'
    elif turma["Media"] >=10 and turma["Media"]<=13:
        turma["situacao"]='Aprovado'
    elif turma["Media"]>=16:
        turma["situacao"]='Dispensado'
for k,v in turma.items():
    print(f'{k} e igual a {v}')
