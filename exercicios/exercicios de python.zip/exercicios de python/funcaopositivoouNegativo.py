def numero(n):
    if n >0:
        print('p')
    if n <= 0 :
        print('N')
numero(-35)
