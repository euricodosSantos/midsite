def soma(n=0,a=0,e=0,):
      somar=n+a+e
      print(somar)
soma(10,5,6)

