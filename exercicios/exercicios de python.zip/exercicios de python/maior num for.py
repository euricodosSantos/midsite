print('Comparador de numeros ')
maior=1

for a in range (1 ,6):

    numero=int(input(f'digite o {a} valor :  '))
    if a ==1 and maior< numero :
        maior=numero
    elif a > 1 and maior < numero:
        maior=numero

print(f'O maior valor digitado e {maior}')