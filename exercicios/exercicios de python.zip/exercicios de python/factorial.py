print('Calculando factorial')
numero=int(input('digite o numero que preetende verificar o factorial : '))
print('O factorial do numero que verificou e de  ', end=' ')
factorial =1
for i in range(1,numero+1):
        factorial=factorial*i
print(factorial)