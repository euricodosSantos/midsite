def somaimposto(taxaimposto,custo):
    valor=(taxaimposto*custo)/100
    total=valor+custo
    print(total)

somaimposto(12,100)