print('intervalo dos numeros ')
num1=int(input('digite o seu primeiro numero :  '.upper()))
num2=int(input('digite o seu segundo numero : '.upper()))
print('Os numeros que estao no intervalo entre esses dois numeros sao: ')
soma=0
for a in range(num1+1,num2):
    soma+=a
    print(a,end='  ')

if num1 > num2:
    for a in range(num2+1,num1):
        soma+=a
        print(a,end='==> ')
print(f'E a soma de todos os valores e de : {soma}')

