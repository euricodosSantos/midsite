impar=[]
par=[]
total=[]
print('Dividindo par e impar em listas diferentes')
for i in range(1,10):
    numero=int(input(f'digite o {i} numero :  '))
    total.append(numero)
    if numero % 2 ==0:
        par.append(numero)
    elif numero %2 ==1 :
        impar.append(numero)
print('0S numeros pares sao : ',end='')
for b,a in enumerate(par):
    print(a,end=' ')
print('\n os numeros impares sao : ',end=' ')
for b ,a in enumerate(impar):
    print(a , end=' ')
print(f'\n{"="*50}')
print(f' A lista completa {total} ')