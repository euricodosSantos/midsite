lista=[]
soma=0
media=0
print('deseja verificar a sua media digite as suas notas : ')
for i in range (1,5):
    notas=float(input(f'digite a {i} nota :  '))
    soma+=notas
    media = soma /i
    lista.append(notas)
for b,c in enumerate ( lista):
 print(f'A {b+1} nota e {c}')
print(f'{"="*50}')
print(f'A sua media e  de {media}')


