#dicionarios de dados
# append n funciona nos dicionarios
# del para remover elementos
#print(filmes.values()) # mostra somente os valores
#print(filmes.keys()) # mostra todas as chaves do dicionario
#print(filmes.items()) #mostra todos os printes dos dicionarios

#filme={'titulo':'star wars','ano':17}
#print(filme.keys())
#pessoas={'nome':'Gustavo','sexo':'M','idade':22}
#### print(f'{k}={v}')
#estado1={'uf':'Rio de Janeiro', 'sigla':'RJ'}
####razil.append(estado2)
#print(brazil[1])
estado={}
brazil=[]
for c in range(1,3):
    estado['uf']=str(input('Unidade federativa:  '))
    estado['sigla'] = str(input('sigla do estado :   '))
    brazil.append(estado.copy())
for e in brazil:
    for k,v in e.items():
        print(f'o campo {k} tem valor {v} .', end='  ')
        print('')

