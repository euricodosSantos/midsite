mult=0
soma=0
lista=list()
for i in range(1,5):
    lista.append(int(input(f'Digite o {i} numero :  ')))
print('='*40)
for a,i in enumerate(lista):
    mult = lista[a] * lista[a]
    soma=soma+mult
    print(f'o Quadrado do numero {lista[a]} = {lista[a]*lista[a]}')
print('='*40)
print(f'A soma dos quadrados dos valores na lista e de {soma}')