let dadoj1 = 0
let dadoj2 = 0
let quad = [9, 9, 9, 9, 9, 9, 9, 9, 9]
let jogatual = 2
let aviso = 0
let jogador = 0
let jogo = 0

let jogdv = document.getElementById('jogdv')

let pos0 = document.getElementById('img01')
let pos1 = document.getElementById('img02')
let pos2 = document.getElementById('img03')
let pos3 = document.getElementById('img04')
let pos4 = document.getElementById('img05')
let pos5 = document.getElementById('img06')
let pos6 = document.getElementById('img07')
let pos7 = document.getElementById('img08')
let pos8 = document.getElementById('img09')

let posicao = [pos0, pos1, pos2, pos3, pos4, pos5, pos6, pos7, pos8]

function jogar(pos) {
    if (jogagorInval(dadoj1)) {
        window.alert('[] COMECE OU REINICIE O JOGO![]')
    } else {
        if (verPos(pos) == !true) {
            if (jogatual == 1) {
                quad[pos] = dadoj1
                trocarImg(pos, dadoj1)

            } else if (jogatual == 2) {
                quad[pos] = dadoj2
                trocarImg(pos, dadoj2)
            }
        } else {
            aviso++
            if (aviso >= 3) {
                window.alert('Posicao invalida! Jogue uma posicao nao preenchida.')
                aviso = 0
            }
        }
        jogadAtual(jogatual)
        terminar()
        verComb(dadoj2)
        verComb(dadoj1)
    }
}

function atriDado() { //atribui o dados escolhidos aos jogadores
    if (jogo == 0) {
        window.alert('REMOVA A ABA DE PORNO! ESSE JOGO PODE SER MAIS PESADO QUE A TUA TIA GORDA!')
        let x = window.prompt(`Digite seu nome: `)
        window.alert(`Obrigado por digitar seu nome ${x}! Ele nao tera utilidade aqui.`)
        window.alert('Entao e voce, o famoso dador de rabo!')
        jogo = 1
        jogadAtual(jogatual)
        let j1 = document.getElementsByName('radioj1')
        let j2 = document.getElementsByName('radioj2')
        if (j1[0].checked) {
            j2[1].checked = true // Coloca o o atributo checked na opcao contraria do jogador 1
            dadoj1 = 1 // x
            dadoj2 = 2 // o
        } else if (j1[1].checked) {
            j2[0].checked = true // Coloca o o atributo checked na opcao contraria do jogador 1
            dadoj1 = 2 // o
            dadoj2 = 1 // x
        }
    } else {
        window.alert('O JOGO JA FOI INICIADO')
    }
}

function verPos(pos) { //Ve se a posicao esta preenchida7
    if (quad[pos] != 9) {
        return true
    } else {
        return false
    }
}

function verComb(dado) { //Ve se algum usario ganhou
    let h = quad[0] == dado && quad[1] == dado && quad[2] == dado || quad[3] == dado && quad[4] == dado && quad[5] == dado || quad[6] == dado && quad[7] == dado && quad[8] == dado
    let v = quad[0] == dado && quad[3] == dado && quad[6] == dado || quad[1] == dado && quad[4] == dado && quad[7] == dado || quad[2] == dado && quad[5] == dado && quad[8] == dado
    let o = quad[0] == dado && quad[4] == dado && quad[8] == dado || quad[2] == dado && quad[4]== dado && quad[6] == dado
    if (h || v || o) {
        jogdv.innerHTML = `O <strong>jogador ${dado}</strong> venceu!`
        window.alert('FIM DO JOGO')
        dadoj1 = 0
    }
}

function jogadAtual(jog) {
    if (jog == 1) {
        jogdv.innerHTML = `<strong>Jogador 2</strong>`
        jogdv.style.textAlign = 'center'
        jogatual = 2
    } else if (jog == 2) {
        jogdv.innerHTML = `<strong>Jogador 1</strong>`
        jogdv.style.textAlign = 'center'
        jogatual = 1
    }
}

function trocarImg(pimg, dado) {
    if (dado == 1) {
        posicao[pimg].src = 'imagens/imagemx.png'

    } else if (dado == 2) {
        posicao[pimg].src = 'imagens/imagemo.png'
    }
}

function jogagorInval(jog) {
    if (jog == 0) {
        return true
    }
    else {
        return false
    }
}

function terminar() {
    if (quad.indexOf(9) == -1) {
        window.alert('O JOGO TERMINOU!')
    }
}